"""
Test Python and OpenCV


author: thomas haslwanter
date:   26 July 2013
ver:    1.0
"""

import cv2
import numpy as np
import os

def show_and_wait(myTitle, myImage):
    ''' Show and image, and wait until the user wants to continue '''
    
    # Show the image
    cv2.imshow(myTitle, myImage)
    
    while True:
        # Wait for a keyboard hit
        c = cv2.waitKey(0) % 0x100
        
        # If it is "ESC" or "q", break the while-loop and continue
        if c == 27 or c == ord('q'):
            break
    
    # Close the window properly    
    cv2.destroyWindow(myTitle)
      
def calc_Laplacian(inFile):
    ''' Read in an image and calculate the  Laplacian '''
    
    # Read in a colored image
    img = cv2.imread(inFile, cv2.CV_LOAD_IMAGE_COLOR)
    
    # Calculate the Laplacian
    filtered = cv2.Laplacian(img, cv2.IPL_DEPTH_8U)
    
    # Show both images, one at a time. First, the original image:
    show_and_wait('Original-Hit ESC to continue', img)
    
    # Then, the filtered image (here the Laplacian)    
    show_and_wait('Laplacian-Hit ESC to end', filtered)

if __name__=='__main__':
    ''' The main function: get a file, and show how to calculate the Laplacian. '''

    # The OpenCV demos:
    calc_Laplacian('sonne_s.jpg')
    
    print 'Done!  :)'
    
    